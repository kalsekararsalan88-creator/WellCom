# WellCom Professional Prototype v2

Added:
- Professional visible Dark/Light Mode toggle with saved preference
- Fun "Check Your Mood" tool with fingerprint-style tap interaction and random emoji mood
- Clear note that the mood result is random and does not read biometric fingerprint data
- Existing WellCom utility tools and responsive professional UI

Backend-required tools remain UI-ready: PDF→Word, Word→PDF, PPT→PDF and true PDF compression.
